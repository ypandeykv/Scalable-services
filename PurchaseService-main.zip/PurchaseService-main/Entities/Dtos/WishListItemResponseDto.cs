﻿namespace Entities.Dtos
{
    public class WishListItemResponseDto
    {
        public Guid ProductId { get; set; }
    }
}
