﻿namespace Entities.Dtos
{
    public class AddToCartUpdateDto
    {
        public List<CartProductUpdateDto>? Products = new List<CartProductUpdateDto>();
    }
}
