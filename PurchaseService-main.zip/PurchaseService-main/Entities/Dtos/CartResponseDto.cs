﻿namespace Entities.Dtos
{
    public class CartResponseDto
    {
        public Guid ProductId { get; set; }

        public int Quantity { get; set; }
    }
}
