﻿namespace Entities.Dtos
{
    public class IdentityResponseDto
    {
        public Guid Id { get; set; }
    }
}
